package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="data")
public class Transaction {

	private long cardNo;
	private String cardName;
    private int month;
    private int year;
	@Id
    private int cvv;
    private int amount;
    public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}
public Transaction(long cardNo, String cardName, int month, int year, int cvv,int amount) {
	super();
	this.cardNo = cardNo;
	this.cardName = cardName;
	this.month = month;
	this.year = year;
	this.cvv = cvv;
	this.amount=amount;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public long getCardNo() {
	return cardNo;
}
public void setCardNo(long cardNo) {
	this.cardNo = cardNo;
}
public String getCardName() {
	return cardName;
}
public void setCardName(String cardName) {
	this.cardName = cardName;
}
public int getMonth() {
	return month;
}
public void setMonth(int month) {
	this.month = month;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public int getCvv() {
	return cvv;
}
public void setCvv(int cvv) {
	this.cvv = cvv;
}
public CartItem getOrdItem() {
	// TODO Auto-generated method stub
	return null;
}
}

