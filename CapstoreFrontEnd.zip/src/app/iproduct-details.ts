export class IProductDetails {

    prodId: string;
	prodName: string;
	prodCategory: string;
	price: number;
	discount: number;
	validTime: string;
	promoCode: string;
	viewsCount: number;
	qty: number;
	constructor(prodName:string,price:number,
		discount:number){
	this.prodName=prodName;
	this.price=price;
	this.discount=discount;
		}
}
