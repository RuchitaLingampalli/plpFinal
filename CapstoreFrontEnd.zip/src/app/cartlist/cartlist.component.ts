import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { Cartlist } from '../cartlist';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cartlist',
  templateUrl: './cartlist.component.html',
  styleUrls: ['./cartlist.component.css']
})
export class CartlistComponent implements OnInit {

  router: Router;
 
  constructor(private service:CapStoreService, router: Router) {
    this.router = router;
   }

  cartlist:Cartlist[];
  ngOnInit() {
    this.service.getCartProducts().subscribe(data => {
      this.cartlist = data;
      console.log(this.cartlist);
      });
  }
  deleteFromCart(cartId) {
    if (confirm("Are you Sure to REMOVE??")) {
    this.service.deleteFromCart(cartId).subscribe(data => {
    this.cartlist = data;
   });
    }
    
    }

  
}
