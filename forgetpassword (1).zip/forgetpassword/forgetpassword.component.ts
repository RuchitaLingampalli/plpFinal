import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapServiceService } from '../cap-service.service';

@Component({
  selector: 'forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
  message:string

  constructor(private router: Router, private capServiceService: CapServiceService ) { }

  ngOnInit() {
  }

  forgotpwd(email){
  
    alert("EMAIL SENT SUCCESFULLY")
    this.router.navigate(['/customerlogin']);
  }
}